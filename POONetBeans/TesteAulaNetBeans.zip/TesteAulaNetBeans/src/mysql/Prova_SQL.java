package mysql;

import java.sql.Connection;

public class Prova_SQL {
    //abrir conexao
    Connection conexao = FabricaConexao.getConexao();
    //variveis sql em private
    private String XXXXX1 ="";
    private String XXXXX2 ="";
    //metodos
    public String metodo1(){
        String nada ="";
        return nada;
    }

    public String metodo2(){
        String nada ="";
        return nada;
    }

    //gest and sets ficam dentro do metodos(olhar exmplo Janta feito em aula)

}
